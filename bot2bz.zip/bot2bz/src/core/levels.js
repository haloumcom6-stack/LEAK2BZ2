'use strict';

const { COLORS, EMOJI } = require('./constants');
const { baseEmbed } = require('./embeds');
const { applyPlaceholders, randomInt, formatNumber, progressBar } = require('./utils');

/** Seuils d'XP cumulés (mémoïsés). */
const thresholds = [0];

/** XP total nécessaire pour atteindre un niveau. */
function xpForLevel(level) {
  const safe = Math.max(0, Math.floor(level));
  while (thresholds.length <= safe) {
    const index = thresholds.length;
    thresholds.push(thresholds[index - 1] + 5 * index * index + 50 * index + 100);
  }
  return thresholds[safe];
}

function levelFromXp(xp) {
  let level = 0;
  while (level < 1000 && xp >= xpForLevel(level + 1)) level += 1;
  return level;
}

function getUserData(cfg, userId) {
  const id = String(userId);
  if (!cfg.levels.users[id]) {
    cfg.levels.users[id] = { xp: 0, level: 0, lastXp: 0, messages: 0 };
  }
  return cfg.levels.users[id];
}

function getRank(cfg, userId) {
  const sorted = Object.entries(cfg.levels.users)
    .map(([id, data]) => ({ id, xp: data.xp || 0 }))
    .sort((a, b) => b.xp - a.xp);
  const index = sorted.findIndex((entry) => entry.id === String(userId));
  return { rank: index === -1 ? sorted.length + 1 : index + 1, total: sorted.length };
}

function progressToNext(cfg, userId) {
  const data = getUserData(cfg, userId);
  const level = data.level || levelFromXp(data.xp);
  const currentFloor = xpForLevel(level);
  const nextFloor = xpForLevel(level + 1);
  const current = data.xp - currentFloor;
  const needed = nextFloor - currentFloor;
  return {
    level,
    xp: data.xp,
    current,
    needed,
    percent: needed > 0 ? Math.min(100, Math.round((current / needed) * 100)) : 100,
  };
}

/**
 * Ajoute de l'XP pour un message et gère les montées de niveau.
 */
async function handleMessageXp(message, client) {
  if (!message.inGuild() || message.author.bot) return null;
  const cfg = client.db.guild(message.guild.id);
  if (!cfg.levels.enabled) return null;

  const userId = message.author.id;
  const data = getUserData(cfg, userId);
  const now = Date.now();
  const cooldownMs = Math.max(5, cfg.levels.cooldown || 60) * 1000;
  if (now - (data.lastXp || 0) < cooldownMs) return null;

  data.lastXp = now;
  data.messages = (data.messages || 0) + 1;

  const min = Math.max(1, cfg.levels.xpMin || 15);
  const max = Math.max(min, cfg.levels.xpMax || 25);
  const gain = randomInt(min, max);
  const oldLevel = data.level || 0;
  data.xp = (data.xp || 0) + gain;
  const newLevel = levelFromXp(data.xp);
  data.level = newLevel;
  client.db.save();

  if (newLevel <= oldLevel) return { gain, level: newLevel, levelUp: false };

  const guild = message.guild;
  const channel = cfg.levels.channelId
    ? guild.channels.cache.get(cfg.levels.channelId) || await guild.channels.fetch(cfg.levels.channelId).catch(() => null)
    : message.channel;

  let rewardText = '';
  const rewards = cfg.levels.rewards || {};
  for (const [levelKey, roleId] of Object.entries(rewards)) {
    const rewardLevel = Number(levelKey);
    if (!Number.isFinite(rewardLevel) || rewardLevel > newLevel || rewardLevel <= oldLevel) continue;
    const member = message.member || await guild.members.fetch(userId).catch(() => null);
    const role = guild.roles.cache.get(roleId);
    if (!member || !role) continue;
    if (member.roles.cache.has(roleId)) continue;
    const me = guild.members.me;
    if (me && role.position >= me.roles.highest.position) {
      rewardText += `\n⚠️ Rôle **${role.name}** non attribuable (hiérarchie).`;
      continue;
    }
    const ok = await member.roles.add(role, `Récompense de niveau ${rewardLevel}`).then(() => true).catch(() => false);
    if (ok) rewardText += `\n🎁 Rôle débloqué : ${role}`;
  }

  if (channel?.isTextBased()) {
    const description = applyPlaceholders(cfg.levels.message, { guild, user: message.author, member: message.member })
      .replace(/\{level\}/g, String(newLevel))
      .replace(/\{xp\}/g, formatNumber(data.xp))
      .replace(/\{next\}/g, formatNumber(xpForLevel(newLevel + 1)));

    const embed = baseEmbed({
      color: COLORS.level,
      title: `${EMOJI.sparkles} Niveau supérieur !`,
      description: `${description}${rewardText}`,
      thumbnail: message.author.displayAvatarURL({ size: 128 }),
      fields: [
        { name: 'Niveau', value: `**${newLevel}**`, inline: true },
        { name: 'XP total', value: `**${formatNumber(data.xp)}**`, inline: true },
      ],
      footer: 'Niveaux',
    });
    await channel.send({ embeds: [embed], allowedMentions: { users: [userId] } }).catch(() => null);
  }

  return { gain, level: newLevel, levelUp: true };
}

function addXp(cfg, userId, amount) {
  const data = getUserData(cfg, userId);
  data.xp = Math.max(0, (data.xp || 0) + amount);
  data.level = levelFromXp(data.xp);
  return data;
}

function setXp(cfg, userId, amount) {
  const data = getUserData(cfg, userId);
  data.xp = Math.max(0, Math.floor(amount));
  data.level = levelFromXp(data.xp);
  return data;
}

function leaderboard(cfg, limit = 10) {
  return Object.entries(cfg.levels.users)
    .map(([id, data]) => ({ id, xp: data.xp || 0, level: data.level || 0 }))
    .sort((a, b) => b.xp - a.xp)
    .slice(0, limit);
}

function xpBar(cfg, userId) {
  const progress = progressToNext(cfg, userId);
  return {
    ...progress,
    bar: progressBar(progress.current, progress.needed, 12),
  };
}

module.exports = {
  xpForLevel,
  levelFromXp,
  getUserData,
  getRank,
  progressToNext,
  handleMessageXp,
  addXp,
  setXp,
  leaderboard,
  xpBar,
};
