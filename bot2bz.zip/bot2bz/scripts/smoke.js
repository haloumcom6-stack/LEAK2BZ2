'use strict';

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { Client, GatewayIntentBits, Events } = require('discord.js');
const { registerCommands } = require('../src/handlers/commands');
const { registerEvents, EVENTS_DIR } = require('../src/handlers/events');
const { Database } = require('../src/core/db');
const { GiveawayManager } = require('../src/core/giveaways');

const errors = [];
const warnings = [];
const knownEvents = new Set(Object.values(Events).filter((value) => typeof value === 'string'));

function loadEventModules() {
  if (!fs.existsSync(EVENTS_DIR)) return [];
  const handlers = [];
  const files = fs.readdirSync(EVENTS_DIR).filter((file) => file.endsWith('.js')).sort();

  for (const file of files) {
    const fullPath = path.join(EVENTS_DIR, file);
    let exported;
    try {
      exported = require(fullPath);
    } catch (error) {
      errors.push(`${file} : chargement impossible — ${error.message}`);
      continue;
    }

    const list = Array.isArray(exported) ? exported : [exported];
    if (list.length === 0) {
      errors.push(`${file} : aucun gestionnaire exporté.`);
      continue;
    }

    for (const handler of list) {
      if (!handler || typeof handler !== 'object') {
        errors.push(`${file} : gestionnaire invalide.`);
        continue;
      }
      if (!knownEvents.has(handler.name)) {
        errors.push(`${file} : événement inconnu "${handler.name}".`);
      }
      if (typeof handler.execute !== 'function') {
        errors.push(`${file} : "${handler.name}" n’a pas de fonction execute().`);
      }
      handlers.push({ file, handler });
    }
  }
  return handlers;
}

const handlers = loadEventModules();
const uniqueNames = new Set(handlers.map(({ handler }) => handler.name));

const client = new Client({ intents: [GatewayIntentBits.Guilds] });
let commandCount = 0;
let eventCount = 0;

try {
  commandCount = registerCommands(client);
  eventCount = registerEvents(client);
} catch (error) {
  errors.push(`Enregistrement impossible — ${error.stack || error.message}`);
}

if (commandCount !== client.commands.size) {
  errors.push(`Commandes enregistrées incohérentes : ${commandCount} chargées, ${client.commands.size} indexées.`);
}
if (eventCount !== handlers.length) {
  errors.push(`Événements enregistrés incohérents : ${eventCount} enregistrés, ${handlers.length} déclarés.`);
}

for (const [name, command] of client.commands) {
  if (!command.data?.name || command.data.name !== name) {
    errors.push(`Index de commande incohérent pour "/${name}".`);
  }
}

let db = null;
let dbFile = null;
try {
  dbFile = path.join(os.tmpdir(), `l2b-smoke-${process.pid}.json`);
  db = new Database(dbFile);
  const giveaways = new GiveawayManager(client, db);
  if (typeof giveaways.listForGuild !== 'function' || typeof giveaways.restore !== 'function') {
    errors.push('GiveawayManager : interface incomplète.');
  }
  client.db = db;
  client.giveaways = giveaways;
} catch (error) {
  errors.push(`Initialisation des gestionnaires impossible — ${error.message}`);
}

try {
  db?.flush();
} catch {
  /* ignoré */
}
for (const file of [dbFile, dbFile && `${dbFile}.tmp`]) {
  if (!file) continue;
  try {
    fs.rmSync(file, { force: true });
  } catch {
    /* ignoré */
  }
}

console.log(`\n🧪 Smoke test : ${commandCount} commande(s), ${handlers.length} gestionnaire(s) d’événements (${uniqueNames.size} événement(s) distinct(s)).`);
if (warnings.length) {
  console.log('\n⚠️ Avertissements :');
  for (const warning of warnings) console.log(`  - ${warning}`);
}

if (errors.length) {
  console.error('\n❌ Erreurs :');
  for (const error of errors) console.error(`  - ${error}`);
  process.exit(1);
}

console.log('\n✅ Commandes, événements et gestionnaires chargés sans erreur.\n');
