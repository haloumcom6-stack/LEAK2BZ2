'use strict';

const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const { Database } = require('../src/core/db');
const { handleRaidJoin } = require('../src/core/automod');
const { xpForLevel, levelFromXp } = require('../src/core/levels');
const {
  parseDuration,
  findBadWord,
  isAllowedDomain,
  containsInvite,
} = require('../src/core/utils');

const dbFile = path.join(os.tmpdir(), `l2b-test-${process.pid}.json`);
const db = new Database(dbFile);
let failures = 0;

function test(name, fn) {
  try {
    fn();
    console.log(`  ✅ ${name}`);
  } catch (error) {
    failures += 1;
    console.error(`  ❌ ${name} — ${error.message}`);
  }
}

console.log('\n🧪 Tests des fonctions de base\n');

test('parseDuration accepte 10m', () => assert.equal(parseDuration('10m'), 10 * 60 * 1000));
test('parseDuration accepte 2j12h', () => assert.equal(parseDuration('2j12h'), 60 * 60 * 60 * 1000));
test('parseDuration accepte 1h30', () => assert.equal(parseDuration('1h30'), 90 * 60 * 1000));
test('parseDuration refuse une chaîne invalide', () => assert.equal(parseDuration('abc'), null));
test('parseDuration refuse 1h30x', () => assert.equal(parseDuration('1h30x'), null));

test('findBadWord normalise le leet speak', () => assert.equal(findBadWord('tu es un c0nnard', ['connard']), 'connard'));
test('findBadWord ne coupe pas les mots', () => assert.equal(findBadWord('connardise', ['connard']), null));

test('isAllowedDomain accepte un sous-domaine', () => assert.equal(isAllowedDomain('https://www.youtube.com/watch?v=1', ['youtube.com']), true));
test('isAllowedDomain refuse un faux domaine', () => assert.equal(isAllowedDomain('https://evil-youtube.com', ['youtube.com']), false));
test('containsInvite détecte discord.gg', () => assert.equal(containsInvite('rejoins discord.gg/abc'), true));

test('xpForLevel(1) vaut 155', () => assert.equal(xpForLevel(1), 155));
test('xpForLevel(5) vaut 1525', () => assert.equal(xpForLevel(5), 1525));
test('levelFromXp est cohérent', () => assert.equal(levelFromXp(xpForLevel(5)), 5));

async function raidTests() {
  const cfg = db.guild('raid-test');
  cfg.automod.enabled = true;
  cfg.automod.antiraid.enabled = true;
  cfg.automod.antiraid.threshold = 2;
  cfg.automod.antiraid.window = 60;
  cfg.automod.antiraid.minAccountAge = 7;
  cfg.automod.antiraid.lockdown = false;

  const kicked = [];
  const client = {
    db,
    user: { id: 'bot' },
    guilds: { cache: new Map() },
    channels: { cache: new Map(), fetch: async () => null },
  };
  const guild = {
    id: 'raid-test',
    name: 'Test',
    ownerId: 'owner',
    memberCount: 10,
    client,
    roles: { everyone: { id: 'everyone' } },
    channels: client.channels,
    members: { me: null, fetch: async () => null },
    setVerificationLevel: async () => null,
  };
  client.guilds.cache.set(guild.id, guild);

  const makeMember = (ageDays, suffix) => ({
    id: `user-${suffix}`,
    guild,
    kickable: true,
    user: {
      bot: false,
      createdTimestamp: Date.now() - ageDays * 24 * 60 * 60 * 1000,
      tag: `user-${suffix}#0001`,
      username: `user-${suffix}`,
      displayAvatarURL: () => '',
    },
    roles: { cache: new Map() },
    permissions: { has: () => false },
    kick: async (reason) => {
      kicked.push(reason);
      return true;
    },
  });

  const young1 = makeMember(1, 'young1');
  const young2 = makeMember(1, 'young2');
  const old = makeMember(100, 'old');

  assert.equal(await handleRaidJoin(young1, client), false, 'un compte récent ne doit pas être expulsé hors raid');
  assert.equal(kicked.length, 0);
  assert.equal(await handleRaidJoin(young2, client), true, 'le deuxième join doit déclencher le raid et expulser le compte récent');
  assert.equal(kicked.length, 1);
  assert.equal(await handleRaidJoin(old, client), false, 'un compte ancien ne doit pas être expulsé pendant le raid');
  assert.equal(kicked.length, 1);

  cfg.raid.activeUntil = 0;
  cfg.raid.joins = [];
  assert.equal(await handleRaidJoin(makeMember(1, 'young3'), client), false, 'sans raid actif, aucun kick');
  assert.equal(kicked.length, 1);
}

raidTests()
  .then(() => {
    db.flush();
    for (const file of [dbFile, `${dbFile}.tmp`]) {
      try {
        fs.rmSync(file, { force: true });
      } catch {
        /* ignoré */
      }
    }
    if (failures > 0) {
      console.error(`\n❌ ${failures} test(s) en échec.\n`);
      process.exit(1);
    }
    console.log('\n✅ Tous les tests de base sont passés.\n');
  })
  .catch((error) => {
    console.error('\n❌ Tests anti-raid :', error);
    process.exit(1);
  });
