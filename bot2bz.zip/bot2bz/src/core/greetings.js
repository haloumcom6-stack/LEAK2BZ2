'use strict';

const { COLORS, EMOJI } = require('./constants');
const { baseEmbed } = require('./embeds');
const { applyPlaceholders } = require('./utils');

/**
 * Envoie un message de bienvenue ou d'au revoir.
 * @param {import('discord.js').Client} client
 * @param {{ guild: import('discord.js').Guild, user: import('discord.js').User, member?: import('discord.js').GuildMember, kind: 'welcome'|'goodbye', force?: boolean, channel?: import('discord.js').TextChannel, sendDm?: boolean }} options
 */
async function sendGreeting(client, { guild, user, member, kind, force = false, channel = null, sendDm = true }) {
  const cfg = client.db.guild(guild.id);
  const conf = cfg[kind];
  if (!conf) return false;
  if (!force && !conf.enabled) return false;

  let target = channel;
  if (!target && conf.channelId) {
    target = guild.channels.cache.get(conf.channelId)
      || await guild.channels.fetch(conf.channelId).catch(() => null);
  }
  if (!target || !target.isTextBased()) return false;

  const text = applyPlaceholders(conf.message, { guild, user, member }) || '…';
  const isWelcome = kind === 'welcome';
  let payload;

  if (conf.embed) {
    payload = {
      embeds: [baseEmbed({
        color: isWelcome ? COLORS.success : COLORS.neutral,
        title: isWelcome ? `${EMOJI.wave} Bienvenue !` : `${EMOJI.wave} Au revoir…`,
        description: text,
        thumbnail: user.displayAvatarURL({ size: 256 }),
        footer: isWelcome ? 'Bienvenue' : 'Au revoir',
      })],
      allowedMentions: { users: [user.id] },
    };
  } else {
    payload = { content: text, allowedMentions: { users: [user.id] } };
  }

  const sent = await target.send(payload).catch(() => null);
  if (!sent) return false;

  if (isWelcome && sendDm && conf.dm && !force) {
    await user.send({
      embeds: [baseEmbed({
        color: COLORS.success,
        title: `${EMOJI.wave} Bienvenue sur ${guild.name} !`,
        description: text,
        thumbnail: guild.iconURL({ size: 256 }) || undefined,
        footer: guild.name,
      })],
    }).catch(() => null);
  }

  return true;
}

module.exports = { sendGreeting };
