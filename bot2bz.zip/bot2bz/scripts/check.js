'use strict';

const { collectCommandModules } = require('../src/handlers/commands');
const { CATEGORY_META } = require('../src/core/constants');

const errors = [];
const warnings = [];
const NAME_REGEX = /^[-_\p{L}\p{N}\p{sc=Deva}\p{sc=Thai}]{1,32}$/u;
const TYPE_SUBCOMMAND = 1;
const TYPE_GROUP = 2;

function checkDescription(where, description, max = 100) {
  if (typeof description !== 'string' || description.length < 1) {
    errors.push(`${where} : description manquante.`);
    return;
  }
  if (description.length > max) errors.push(`${where} : description trop longue (${description.length}/${max}).`);
}

function checkRequiredOrder(where, options) {
  let seenOptional = null;
  for (const option of options || []) {
    if (!option.required) {
      if (seenOptional === null) seenOptional = option.name;
    } else if (seenOptional !== null) {
      errors.push(`${where} : option obligatoire "${option.name}" placée après l’option facultative "${seenOptional}".`);
    }
  }
}

function checkOptions(where, options) {
  if (!options) return;
  if (options.length > 25) errors.push(`${where} : plus de 25 options/sous-commandes.`);
  checkRequiredOrder(where, options);
  for (const option of options) {
    if (!NAME_REGEX.test(option.name) || option.name !== option.name.toLowerCase()) {
      errors.push(`${where} : nom d’option invalide "${option.name}".`);
    }
    checkDescription(`${where} > ${option.name}`, option.description);
    if (option.choices) {
      if (option.choices.length > 25) errors.push(`${where} > ${option.name} : plus de 25 choix.`);
      for (const choice of option.choices) {
        if (typeof choice.name !== 'string' || choice.name.length > 100) errors.push(`${where} > ${option.name} : nom de choix invalide.`);
        if (typeof choice.value !== 'string' && typeof choice.value !== 'number') errors.push(`${where} > ${option.name} : valeur de choix invalide.`);
      }
    }
    if (option.options) checkOptions(`${where} > ${option.name}`, option.options);
  }
}

let modules;
try {
  modules = collectCommandModules();
} catch (error) {
  console.error('❌ Chargement impossible :\n', error.message);
  process.exit(1);
}

console.log(`\n📦 ${modules.length} commande(s) chargée(s).\n`);

const names = new Map();
const aliases = new Map();
const categoryCounts = new Map();

for (const command of modules) {
  let json;
  try {
    json = command.data.toJSON();
    JSON.stringify(json);
  } catch (error) {
    errors.push(`Commande invalide (sérialisation) : ${error.message}`);
    continue;
  }

  if (!NAME_REGEX.test(json.name) || json.name !== json.name.toLowerCase()) {
    errors.push(`/${json.name} : nom invalide (minuscules, 1-32 caractères).`);
  }
  checkDescription(`/${json.name}`, json.description);
  if (names.has(json.name)) errors.push(`/${json.name} : doublon avec ${names.get(json.name)}.`);
  names.set(json.name, command.category);

  if (!CATEGORY_META[command.category]) errors.push(`/${json.name} : catégorie inconnue "${command.category}".`);
  categoryCounts.set(command.category, (categoryCounts.get(command.category) || 0) + 1);

  for (const alias of command.aliases || []) {
    const normalized = String(alias).toLowerCase();
    if (normalized === json.name) continue;
    if (aliases.has(normalized)) warnings.push(`Alias "${normalized}" défini par /${json.name} et /${aliases.get(normalized)}.`);
    aliases.set(normalized, json.name);
  }

  const topOptions = json.options || [];
  const hasSubcommands = topOptions.some((option) => option.type === TYPE_SUBCOMMAND);
  const hasGroups = topOptions.some((option) => option.type === TYPE_GROUP);
  if ((hasSubcommands || hasGroups) && topOptions.some((option) => option.type !== TYPE_SUBCOMMAND && option.type !== TYPE_GROUP)) {
    errors.push(`/${json.name} : mélange de sous-commandes et d’options simples interdit.`);
  }
  checkOptions(`/${json.name}`, topOptions);
}

console.log('Répartition par catégorie :');
for (const [category, count] of [...categoryCounts.entries()].sort()) {
  console.log(`  • ${CATEGORY_META[category]?.label || category} : ${count}`);
}

if (warnings.length) {
  console.log('\n⚠️ Avertissements :');
  for (const warning of warnings) console.log(`  - ${warning}`);
}

if (errors.length) {
  console.error('\n❌ Erreurs :');
  for (const error of errors) console.error(`  - ${error}`);
  process.exit(1);
}

console.log('\n✅ Toutes les commandes sont valides.\n');
