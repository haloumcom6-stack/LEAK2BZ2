'use strict';

const path = require('node:path');
require('dotenv').config();

const root = path.resolve(__dirname, '..', '..');

const ownerIds = (process.env.OWNER_IDS || '')
  .split(',')
  .map((id) => id.trim())
  .filter((id) => /^\d{15,22}$/.test(id));

module.exports = {
  root,
  token: (process.env.DISCORD_TOKEN || '').trim(),
  clientId: (process.env.CLIENT_ID || '').trim(),
  guildId: (process.env.GUILD_ID || '').trim() || null,
  ownerIds,
  defaultPrefix: process.env.DEFAULT_PREFIX || '!',
  dbPath: path.join(root, 'data', 'database.json'),
  botName: '[! 𝘨𝘦𝘴𝘵𝘪𝘰𝘯 ] L2B🎃',
};
