'use strict';

const { PermissionFlagsBits } = require('discord.js');
const { COLORS, EMOJI } = require('./constants');
const { baseEmbed } = require('./embeds');
const { sendLog } = require('./logs');
const { addCase } = require('./cases');
const {
  containsInvite,
  extractUrls,
  isAllowedDomain,
  looksLikePhishing,
  findBadWord,
  normalizeText,
  formatDuration,
  shorten,
} = require('./utils');

/** Compteurs anti-spam : clé `guildId:userId` -> tableau de timestamps. */
const spamBuckets = new Map();
/** Compteurs de messages identiques : clé `guildId:userId` -> { content, count, at }. */
const duplicateBuckets = new Map();

const EMOJI_REGEX = /[\u{1F000}-\u{1FAFF}\u{2600}-\u{27BF}\u{2B00}-\u{2BFF}]|<a?:\w{2,32}:\d{15,22}>/gu;

function isExempt(member, cfg) {
  if (!member) return true;
  if (member.id === member.guild.ownerId) return true;
  if (member.permissions.has(PermissionFlagsBits.Administrator)) return true;
  if (member.permissions.has(PermissionFlagsBits.ManageGuild)) return true;
  if (member.permissions.has(PermissionFlagsBits.ManageMessages)) return true;
  if (member.permissions.has(PermissionFlagsBits.ModerateMembers)) return true;
  if ((cfg.staff?.roles || []).some((id) => member.roles.cache.has(id))) return true;
  if ((cfg.automod.exemptRoles || []).some((id) => member.roles.cache.has(id))) return true;
  return false;
}

function resetUserBuckets(guildId, userId) {
  spamBuckets.delete(`${guildId}:${userId}`);
  duplicateBuckets.delete(`${guildId}:${userId}`);
}

function checkSpam(message, settings) {
  const key = `${message.guild.id}:${message.author.id}`;
  const now = Date.now();
  const windowMs = Math.max(2, settings.window || 7) * 1000;
  const threshold = Math.max(3, settings.threshold || 6);

  let bucket = spamBuckets.get(key);
  if (!bucket) {
    bucket = [];
    spamBuckets.set(key, bucket);
  }
  bucket.push(now);
  while (bucket.length && now - bucket[0] > windowMs) bucket.shift();

  const normalized = normalizeText(message.content).replace(/\s+/g, ' ').trim();
  let duplicate = duplicateBuckets.get(key);
  if (!duplicate || now - duplicate.at > 30_000 || duplicate.content !== normalized) {
    duplicate = { content: normalized, count: 1, at: now };
  } else {
    duplicate.count += 1;
    duplicate.at = now;
  }
  duplicateBuckets.set(key, duplicate);

  if (bucket.length >= threshold) {
    resetUserBuckets(message.guild.id, message.author.id);
    return `spam de messages (${threshold} messages en ${settings.window}s)`;
  }
  if (normalized.length > 3 && duplicate.count >= 4) {
    resetUserBuckets(message.guild.id, message.author.id);
    return 'envoi répété du même message';
  }
  if (spamBuckets.size > 5000) spamBuckets.clear();
  if (duplicateBuckets.size > 5000) duplicateBuckets.clear();
  return null;
}

function checkCaps(content, settings) {
  const letters = content.replace(/[^\p{L}]/gu, '');
  if (letters.length < (settings.minLength || 14)) return false;
  const uppercase = letters.replace(/[^\p{Lu}]/gu, '').length;
  return (uppercase / letters.length) * 100 >= (settings.percent || 75);
}

function countEmojis(content) {
  EMOJI_REGEX.lastIndex = 0;
  return (content.match(EMOJI_REGEX) || []).length;
}

/**
 * Applique une sanction automod complète : suppression, action, log, dossier, MP.
 */
async function punish(message, rule, reason, settings, client) {
  const guild = message.guild;
  const cfg = client.db.guild(guild.id);
  const member = message.member || await guild.members.fetch(message.author.id).catch(() => null);

  await message.delete().catch(() => null);

  const action = settings.action || 'delete';
  const durationMs = Math.max(1, settings.duration || 300) * 1000;
  let applied = 'Suppression du message';
  let caseDuration = null;

  if (action === 'timeout' && member) {
    if (member.moderatable) {
      const timeout = Math.min(durationMs, 28 * 24 * 60 * 60 * 1000);
      const ok = await member.timeout(timeout, `Automod : ${reason}`).then(() => true).catch(() => false);
      applied = ok ? `Exclusion temporaire (${formatDuration(timeout)})` : 'Suppression (exclusion impossible)';
      if (ok) caseDuration = timeout;
    } else {
      applied = 'Suppression (membre non modérable)';
    }
  } else if (action === 'kick' && member) {
    const ok = await member.kick(`Automod : ${reason}`).then(() => true).catch(() => false);
    applied = ok ? 'Expulsion' : 'Suppression (expulsion impossible)';
  } else if (action === 'warn') {
    applied = 'Suppression + avertissement';
  }

  const entry = addCase(client.db, guild.id, {
    type: action === 'warn' ? 'warn' : 'automod',
    userId: message.author.id,
    moderatorId: client.user.id,
    reason: `[${rule}] ${reason}`,
    duration: caseDuration,
  });

  const log = baseEmbed({
    color: COLORS.warning,
    title: `${EMOJI.shield} Automod — ${rule}`,
    fields: [
      { name: 'Membre', value: `${message.author.tag || message.author.username} (${message.author.id})`, inline: true },
      { name: 'Salon', value: `<#${message.channelId}>`, inline: true },
      { name: 'Action', value: applied, inline: true },
      { name: 'Raison', value: reason, inline: false },
      { name: 'Message', value: shorten(message.content, 1000) || '*Aucun texte*', inline: false },
      { name: 'Dossier', value: `#${entry.id}`, inline: true },
    ],
    footer: 'Automod',
  });
  await sendLog(guild, 'mod', log);

  const notice = await message.channel.send({
    content: `${EMOJI.warning} ${message.author}, ton message a été supprimé par l’automod (**${reason}**).`,
    allowedMentions: { users: [message.author.id] },
  }).catch(() => null);
  if (notice) setTimeout(() => notice.delete().catch(() => null), 6000);

  await message.author.send({
    embeds: [baseEmbed({
      color: COLORS.warning,
      title: `${EMOJI.shield} Automod — ${guild.name}`,
      description: `Ton message a été supprimé.\n\n**Raison :** ${reason}\n**Action :** ${applied}`,
      footer: 'Automod',
    })],
  }).catch(() => null);

  return true;
}

/**
 * Analyse un message et applique l'automod si nécessaire.
 * @returns {Promise<boolean>} true si le message a été sanctionné/supprimé.
 */
async function runAutomod(message, client, { skipSpam = false } = {}) {
  if (!message.inGuild() || message.author.bot || message.system) return false;

  const guild = message.guild;
  const cfg = client.db.guild(guild.id);
  if (!cfg.automod.enabled) return false;

  const member = message.member || await guild.members.fetch(message.author.id).catch(() => null);
  if (!member || member.user.bot) return false;
  if (isExempt(member, cfg)) return false;
  if ((cfg.automod.exemptChannels || []).includes(message.channelId)) return false;

  const content = message.content || '';
  const antilink = cfg.automod.antilink;
  const antiinvite = cfg.automod.antiinvite;

  if (antiinvite.enabled && containsInvite(content)) {
    return punish(message, 'Anti-invitation', 'invitation Discord non autorisée', antiinvite, client);
  }

  if (antilink.enabled) {
    const urls = extractUrls(content);
    if (urls.length > 0) {
      if (antilink.blockPhishing && looksLikePhishing(content, cfg.automod.phishingWords)) {
        return punish(message, 'Anti-phishing', 'lien potentiellement frauduleux', antilink, client);
      }
      const blocked = urls.filter((url) => !isAllowedDomain(url, antilink.allowedDomains));
      if (blocked.length > 0) {
        return punish(message, 'Anti-lien', `lien non autorisé (${shorten(blocked[0], 150)})`, antilink, client);
      }
    }
  }

  if (cfg.automod.badwords.enabled && content.length > 0) {
    const found = findBadWord(content, cfg.automod.badwords.words);
    if (found) {
      return punish(message, 'Mots interdits', `mot interdit détecté (**${found}**)`, cfg.automod.badwords, client);
    }
  }

  if (!skipSpam && cfg.automod.antispam.enabled) {
    const spamReason = checkSpam(message, cfg.automod.antispam);
    if (spamReason) {
      return punish(message, 'Anti-spam', spamReason, cfg.automod.antispam, client);
    }
  }

  if (cfg.automod.antimention.enabled) {
    const mentions = message.mentions.users.size + message.mentions.roles.size;
    if (mentions > (cfg.automod.antimention.max || 6)) {
      return punish(message, 'Anti-mentions', `trop de mentions (${mentions})`, cfg.automod.antimention, client);
    }
  }

  if (cfg.automod.anticaps.enabled && checkCaps(content, cfg.automod.anticaps)) {
    return punish(message, 'Anti-majuscules', 'message écrit en majuscules', cfg.automod.anticaps, client);
  }

  if (cfg.automod.antiemoji.enabled) {
    const count = countEmojis(content);
    if (count > (cfg.automod.antiemoji.max || 15)) {
      return punish(message, 'Anti-emojis', `trop d’emojis (${count})`, cfg.automod.antiemoji, client);
    }
  }

  return false;
}

/**
 * Détecte les raids à l'arrivée de nouveaux membres.
 * @returns {Promise<boolean>} true si le membre a été expulsé.
 */
async function handleRaidJoin(member, client) {
  const cfg = client.db.guild(member.guild.id);
  const settings = cfg.automod.antiraid;
  if (!cfg.automod.enabled || !settings.enabled) return false;
  if (member.user.bot) return false;

  const now = Date.now();
  const windowMs = Math.max(5, settings.window || 20) * 1000;
  cfg.raid.joins = (cfg.raid.joins || []).filter((timestamp) => now - timestamp < windowMs);
  cfg.raid.joins.push(now);

  if (cfg.raid.activeUntil && cfg.raid.activeUntil < now) cfg.raid.activeUntil = 0;

  const accountAgeDays = (now - member.user.createdTimestamp) / (24 * 60 * 60 * 1000);
  const minAge = settings.minAccountAge || 7;
  const tooYoung = accountAgeDays < minAge;

  const triggerRaid = cfg.raid.joins.length >= (settings.threshold || 8) && !cfg.raid.activeUntil;
  if (triggerRaid) {
    cfg.raid.activeUntil = now + 10 * 60 * 1000;
    cfg.raid.joins = [];
    const alert = baseEmbed({
      color: COLORS.error,
      title: `${EMOJI.warning} Raid détecté`,
      description: `**${settings.threshold} membres** ont rejoint en moins de **${settings.window}s**.\nLe mode anti-raid est actif pendant **10 minutes**.`,
      fields: [
        { name: 'Comptes récents', value: `Expulsion automatique des comptes de moins de **${minAge} jours**.`, inline: false },
      ],
      footer: 'Anti-raid',
    });
    await sendLog(member.guild, 'mod', alert);

    if (settings.lockdown) {
      await member.guild.setVerificationLevel(4, 'Anti-raid : niveau de vérification élevé').catch(() => null);
    }
  }

  client.db.save();

  const raidActive = Boolean(cfg.raid.activeUntil && cfg.raid.activeUntil > now);
  // Hors raid actif, les nouveaux membres ne sont jamais expulsés.
  // Pendant un raid, seuls les comptes plus jeunes que l'âge configuré le sont.
  if (!raidActive || !tooYoung) return false;

  if (member.kickable) {
    const reason = `Anti-raid : compte créé il y a moins de ${minAge} jours`;
    const kicked = await member.kick(reason).then(() => true).catch(() => false);
    if (!kicked) return false;

    const entry = addCase(client.db, member.guild.id, {
      type: 'raid',
      userId: member.id,
      moderatorId: client.user.id,
      reason,
    });

    await sendLog(member.guild, 'mod', baseEmbed({
      color: COLORS.error,
      title: `${EMOJI.shield} Anti-raid — membre expulsé`,
      fields: [
        { name: 'Membre', value: `${member.user.tag || member.user.username} (${member.id})`, inline: true },
        { name: 'Âge du compte', value: `${accountAgeDays.toFixed(1)} jour(s)`, inline: true },
        { name: 'Raison', value: reason, inline: false },
        { name: 'Dossier', value: `#${entry.id}`, inline: true },
      ],
      thumbnail: member.user.displayAvatarURL(),
      footer: 'Anti-raid',
    }));
    return true;
  }

  return false;
}

function clearRaidMode(guildId, client) {
  const cfg = client.db.guild(guildId);
  cfg.raid.activeUntil = 0;
  cfg.raid.joins = [];
  client.db.save();
}

module.exports = {
  runAutomod,
  handleRaidJoin,
  clearRaidMode,
  checkSpam,
  resetUserBuckets,
  isExempt,
};
