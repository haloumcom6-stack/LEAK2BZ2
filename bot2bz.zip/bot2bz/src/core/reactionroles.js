'use strict';

/** Vérifie si un emoji configuré correspond à l'emoji d'une réaction. */
function matchesReaction(stored, reactionEmoji) {
  if (!stored || !reactionEmoji) return false;
  if (stored.startsWith('<')) {
    const id = stored.match(/\d{15,22}/)?.[0];
    return Boolean(id && reactionEmoji.id === id);
  }
  return reactionEmoji.name === stored;
}

function emojiLabel(stored) {
  return stored?.startsWith('<') ? stored.replace('<a:', '<:') : stored;
}

module.exports = { matchesReaction, emojiLabel };
