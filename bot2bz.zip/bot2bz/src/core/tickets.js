'use strict';

const {
  ActionRowBuilder,
  AttachmentBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelType,
  PermissionFlagsBits,
} = require('discord.js');
const { COLORS, EMOJI } = require('./constants');
const { baseEmbed, errorEmbed, successEmbed } = require('./embeds');
const { sendLog } = require('./logs');
const { sanitizeChannelName, discordDate, truncate } = require('./utils');

const CLOSE_BUTTON = 'ticket:close';
const CLAIM_BUTTON = 'ticket:claim';
const OPEN_BUTTON = 'ticket:open';

function panelEmbed(cfg, guild) {
  return baseEmbed({
    color: COLORS.ticket,
    title: cfg.tickets.panelTitle || `${EMOJI.ticket} Support — Ouvrir un ticket`,
    description: cfg.tickets.panelMessage
      || `Besoin d’aide sur **${guild.name}** ?\nClique sur le bouton ci-dessous pour ouvrir un ticket privé avec l’équipe de modération.`,
    fields: [
      { name: '📋 Comment ça marche ?', value: '1. Clique sur **Ouvrir un ticket**.\n2. Un salon privé est créé pour toi.\n3. Décris ta demande, le staff arrive.', inline: false },
      { name: '⏱️ Patience', value: 'Les réponses peuvent prendre un peu de temps. Évite d’ouvrir plusieurs tickets.', inline: false },
    ],
    footer: 'Support',
  });
}

function panelComponents() {
  return [
    new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(OPEN_BUTTON)
        .setLabel('Ouvrir un ticket')
        .setEmoji('🎫')
        .setStyle(ButtonStyle.Primary),
    ),
  ];
}

async function sendPanel(channel, client) {
  const cfg = client.db.guild(channel.guild.id);
  return channel.send({
    embeds: [panelEmbed(cfg, channel.guild)],
    components: panelComponents(),
    allowedMentions: { parse: [] },
  });
}

function isTicketStaff(interaction, cfg) {
  const member = interaction.member;
  if (!member) return false;
  if (member.permissions.has(PermissionFlagsBits.Administrator)) return true;
  if (member.permissions.has(PermissionFlagsBits.ManageChannels)) return true;
  if (member.permissions.has(PermissionFlagsBits.ManageGuild)) return true;
  const roleId = cfg.tickets.supportRoleId;
  return Boolean(roleId && member.roles.cache.has(roleId));
}

async function safeReply(interaction, payload, { ephemeral = true } = {}) {
  if (interaction.deferred) return interaction.editReply(payload);
  if (interaction.replied) return interaction.followUp({ ...payload, ephemeral });
  return interaction.reply({ ...payload, ephemeral });
}

async function openTicket(interaction) {
  const client = interaction.client;
  const cfg = client.db.guild(interaction.guild.id);

  if (!cfg.tickets.enabled) {
    return safeReply(interaction, { embeds: [errorEmbed('Le système de tickets n’est pas configuré sur ce serveur.')] });
  }

  await interaction.deferReply({ ephemeral: true }).catch(() => null);

  const existingId = cfg.tickets.open?.[interaction.user.id];
  if (existingId) {
    const existing = interaction.guild.channels.cache.get(existingId)
      || await interaction.guild.channels.fetch(existingId).catch(() => null);
    if (existing) {
      return interaction.editReply({ embeds: [errorEmbed(`Tu as déjà un ticket ouvert : <#${existing.id}>.`)] });
    }
    delete cfg.tickets.open[interaction.user.id];
    delete cfg.tickets.channels[existingId];
    client.db.save();
  }

  const supportRole = cfg.tickets.supportRoleId
    ? interaction.guild.roles.cache.get(cfg.tickets.supportRoleId)
    : null;
  const category = cfg.tickets.categoryId
    ? interaction.guild.channels.cache.get(cfg.tickets.categoryId)
      || await interaction.guild.channels.fetch(cfg.tickets.categoryId).catch(() => null)
    : null;

  cfg.tickets.counter = (cfg.tickets.counter || 0) + 1;
  const number = cfg.tickets.counter;
  const me = interaction.guild.members.me;

  const overwrites = [
    {
      id: interaction.guild.roles.everyone.id,
      deny: [PermissionFlagsBits.ViewChannel],
    },
    {
      id: interaction.user.id,
      allow: [
        PermissionFlagsBits.ViewChannel,
        PermissionFlagsBits.SendMessages,
        PermissionFlagsBits.ReadMessageHistory,
        PermissionFlagsBits.AttachFiles,
        PermissionFlagsBits.AddReactions,
      ],
    },
    {
      id: client.user.id,
      allow: [
        PermissionFlagsBits.ViewChannel,
        PermissionFlagsBits.SendMessages,
        PermissionFlagsBits.ReadMessageHistory,
        PermissionFlagsBits.ManageChannels,
        PermissionFlagsBits.AttachFiles,
        PermissionFlagsBits.EmbedLinks,
      ],
    },
  ];
  if (supportRole) {
    overwrites.push({
      id: supportRole.id,
      allow: [
        PermissionFlagsBits.ViewChannel,
        PermissionFlagsBits.SendMessages,
        PermissionFlagsBits.ReadMessageHistory,
        PermissionFlagsBits.AttachFiles,
        PermissionFlagsBits.ManageMessages,
      ],
    });
  }

  let channel;
  try {
    channel = await interaction.guild.channels.create({
      name: `ticket-${String(number).padStart(4, '0')}-${sanitizeChannelName(interaction.user.username)}`.slice(0, 100),
      type: ChannelType.GuildText,
      parent: category?.type === ChannelType.GuildCategory ? category.id : undefined,
      topic: `Ticket #${number} • ${interaction.user.tag || interaction.user.username} (${interaction.user.id})`,
      permissionOverwrites: overwrites,
      reason: `Ticket ouvert par ${interaction.user.tag || interaction.user.username}`,
    });
  } catch (error) {
    console.error('[TICKET] Création impossible :', error);
    return interaction.editReply({
      embeds: [errorEmbed('Impossible de créer le salon du ticket. Vérifie mes permissions **Gérer les salons** et la position de mon rôle.')],
    });
  }

  cfg.tickets.open[interaction.user.id] = channel.id;
  cfg.tickets.channels[channel.id] = {
    userId: interaction.user.id,
    number,
    openedAt: Date.now(),
    claimedBy: null,
  };
  client.db.save();

  const embed = baseEmbed({
    color: COLORS.ticket,
    title: `${EMOJI.ticket} Ticket #${String(number).padStart(4, '0')}`,
    description: cfg.tickets.welcomeMessage,
    fields: [
      { name: 'Utilisateur', value: `${interaction.user} (${interaction.user.id})`, inline: true },
      { name: 'Ouvert', value: discordDate(Date.now(), 'f'), inline: true },
      { name: 'Statut', value: '🟡 En attente', inline: true },
    ],
    footer: 'Support',
  });

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(CLAIM_BUTTON)
      .setLabel('Prendre en charge')
      .setEmoji('🙋')
      .setStyle(ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId(CLOSE_BUTTON)
      .setLabel('Fermer le ticket')
      .setEmoji('🔒')
      .setStyle(ButtonStyle.Danger),
  );

  const mention = supportRole ? `${interaction.user} ${supportRole}` : `${interaction.user}`;
  const panelMessage = await channel.send({
    content: mention,
    embeds: [embed],
    components: [row],
    allowedMentions: { users: [interaction.user.id], roles: supportRole ? [supportRole.id] : [] },
  }).catch(() => null);
  if (panelMessage) {
    await panelMessage.pin().catch(() => null);
  }

  await sendLog(interaction.guild, 'tickets', baseEmbed({
    color: COLORS.ticket,
    title: `${EMOJI.ticket} Ticket ouvert`,
    fields: [
      { name: 'Utilisateur', value: `${interaction.user.tag || interaction.user.username} (${interaction.user.id})`, inline: true },
      { name: 'Salon', value: `<#${channel.id}>`, inline: true },
      { name: 'Numéro', value: `#${number}`, inline: true },
    ],
    footer: 'Support',
  }));

  return interaction.editReply({
    embeds: [successEmbed(`Ton ticket a été créé : <#${channel.id}> !`, '🎫 Ticket ouvert')],
  });
}

async function claimTicket(interaction) {
  const client = interaction.client;
  const cfg = client.db.guild(interaction.guild.id);
  const ticket = cfg.tickets.channels?.[interaction.channelId];
  if (!ticket) {
    return safeReply(interaction, { embeds: [errorEmbed('Ce salon n’est pas un ticket.')] });
  }
  if (!isTicketStaff(interaction, cfg)) {
    return safeReply(interaction, { embeds: [errorEmbed('Seul le staff peut prendre en charge un ticket.')] });
  }
  if (ticket.claimedBy) {
    return safeReply(interaction, { embeds: [errorEmbed(`Ce ticket est déjà pris en charge par <@${ticket.claimedBy}>.`)] });
  }

  ticket.claimedBy = interaction.user.id;
  client.db.save();

  await interaction.channel.send({
    embeds: [baseEmbed({
      color: COLORS.success,
      title: '🙋 Ticket pris en charge',
      description: `Ce ticket est désormais suivi par ${interaction.user}.\nMerci de patienter, le staff revient vers toi rapidement.`,
      footer: 'Support',
    })],
  }).catch(() => null);

  return safeReply(interaction, {
    embeds: [successEmbed(`Tu as pris en charge le ticket de <@${ticket.userId}>.`)],
  });
}

async function buildTranscript(channel) {
  const messages = new Map();
  let before;
  for (let i = 0; i < 6; i++) {
    const batch = await channel.messages.fetch({ limit: 100, before }).catch(() => null);
    if (!batch || batch.size === 0) break;
    for (const [id, message] of batch) messages.set(id, message);
    before = batch.last()?.id;
    if (batch.size < 100) break;
  }

  const lines = [
    `Transcript du ticket #${channel.name}`,
    `Serveur : ${channel.guild.name} (${channel.guild.id})`,
    `Salon : #${channel.name} (${channel.id})`,
    `Exporté le : ${new Date().toISOString()}`,
    '='.repeat(70),
    '',
  ];

  const sorted = [...messages.values()].sort((a, b) => a.createdTimestamp - b.createdTimestamp);
  for (const message of sorted) {
    const author = `${message.author.tag || message.author.username} (${message.author.id})`;
    const date = new Date(message.createdTimestamp).toISOString();
    const content = message.cleanContent || message.content || '';
    lines.push(`[${date}] ${author}: ${content}`);
    if (message.attachments.size > 0) {
      for (const attachment of message.attachments.values()) {
        lines.push(`    📎 Pièce jointe : ${attachment.url}`);
      }
    }
    for (const embed of message.embeds) {
      if (embed.title) lines.push(`    [Embed] ${embed.title}`);
      if (embed.description) lines.push(`    [Embed] ${truncate(embed.description, 500)}`);
    }
    lines.push('');
  }

  return Buffer.from(lines.join('\n'), 'utf8');
}

async function closeTicket(interaction, reason = null) {
  const client = interaction.client;
  const cfg = client.db.guild(interaction.guild.id);
  const ticket = cfg.tickets.channels?.[interaction.channelId];
  if (!ticket) {
    return safeReply(interaction, { embeds: [errorEmbed('Ce salon n’est pas un ticket.')] });
  }

  const isOwner = interaction.user.id === ticket.userId;
  if (!isOwner && !isTicketStaff(interaction, cfg)) {
    return safeReply(interaction, { embeds: [errorEmbed('Seul le propriétaire du ticket ou le staff peut le fermer.')] });
  }

  await safeReply(interaction, {
    embeds: [baseEmbed({
      color: COLORS.warning,
      title: '🔒 Fermeture du ticket',
      description: 'Ce ticket va être fermé dans **5 secondes**.\nUn transcript sera envoyé dans les logs du staff.',
      footer: 'Support',
    })],
  }, { ephemeral: false });

  const buffer = await buildTranscript(interaction.channel).catch(() => null);
  if (buffer) {
    await sendLog(interaction.guild, 'tickets', baseEmbed({
      color: COLORS.ticket,
      title: `${EMOJI.ticket} Ticket fermé`,
      fields: [
        { name: 'Utilisateur', value: `<@${ticket.userId}> (${ticket.userId})`, inline: true },
        { name: 'Fermé par', value: `${interaction.user.tag || interaction.user.username} (${interaction.user.id})`, inline: true },
        { name: 'Numéro', value: `#${ticket.number}`, inline: true },
        { name: 'Raison', value: reason || 'Non renseignée', inline: false },
      ],
      footer: 'Support',
    }), {
      files: [new AttachmentBuilder(buffer, { name: `transcript-ticket-${ticket.number}.txt` })],
    });
  }

  delete cfg.tickets.channels[interaction.channelId];
  if (cfg.tickets.open?.[ticket.userId] === interaction.channelId) {
    delete cfg.tickets.open[ticket.userId];
  }
  client.db.save();

  setTimeout(() => {
    interaction.channel.delete(`Ticket fermé par ${interaction.user.tag || interaction.user.username}`).catch(() => null);
  }, 5000).unref?.();
}

async function addUserToTicket(interaction, user) {
  const cfg = interaction.client.db.guild(interaction.guild.id);
  const ticket = cfg.tickets.channels?.[interaction.channelId];
  if (!ticket) return { ok: false, message: 'Ce salon n’est pas un ticket.' };
  if (!isTicketStaff(interaction, cfg) && interaction.user.id !== ticket.userId) {
    return { ok: false, message: 'Seul le staff ou le propriétaire peut ajouter quelqu’un.' };
  }
  const added = await interaction.channel.permissionOverwrites.edit(user.id, {
    ViewChannel: true,
    SendMessages: true,
    ReadMessageHistory: true,
    AttachFiles: true,
  }).then(() => true).catch(() => false);
  return added
    ? { ok: true, message: `${user} a été ajouté au ticket.` }
    : { ok: false, message: 'Impossible d’ajouter cette personne (permissions insuffisantes).' };
}

async function removeUserFromTicket(interaction, user) {
  const cfg = interaction.client.db.guild(interaction.guild.id);
  const ticket = cfg.tickets.channels?.[interaction.channelId];
  if (!ticket) return { ok: false, message: 'Ce salon n’est pas un ticket.' };
  if (!isTicketStaff(interaction, cfg) && interaction.user.id !== ticket.userId) {
    return { ok: false, message: 'Seul le staff ou le propriétaire peut retirer quelqu’un.' };
  }
  if (user.id === ticket.userId) {
    return { ok: false, message: 'Impossible de retirer le propriétaire du ticket.' };
  }
  const removed = await interaction.channel.permissionOverwrites.delete(user.id)
    .then(() => true).catch(() => false);
  return removed
    ? { ok: true, message: `${user} a été retiré du ticket.` }
    : { ok: false, message: 'Impossible de retirer cette personne.' };
}

module.exports = {
  OPEN_BUTTON,
  CLOSE_BUTTON,
  CLAIM_BUTTON,
  panelEmbed,
  panelComponents,
  sendPanel,
  openTicket,
  claimTicket,
  closeTicket,
  addUserToTicket,
  removeUserFromTicket,
  isTicketStaff,
  safeReply,
};
