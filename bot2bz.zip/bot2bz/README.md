# [! 𝘨𝘦𝘴𝘵𝘪𝘰𝘯 ] L2B🎃

Bot Discord de gestion **ultra complet**, entièrement en français : modération, automod, anti-raid, giveaways, tickets, niveaux, logs, bienvenue, annonces, rôles-réactions et utilitaires.

- **58 commandes** slash + préfixe
- **9 catégories** fonctionnelles
- **Base JSON locale**, sans base de données externe
- **Zéro dépendance native** : Node.js et discord.js v14 uniquement
- **Persistance** des giveaways, tickets, sondages, avertissements, tempbans, rôles-réactions et niveaux

---

## Sommaire

1. [Fonctionnalités](#fonctionnalités)
2. [Prérequis](#prérequis)
3. [Installation](#installation)
4. [Configuration `.env`](#configuration-env)
5. [Portail Discord](#portail-discord)
6. [Déploiement des commandes](#déploiement-des-commandes)
7. [Démarrage](#démarrage)
8. [Configuration initiale recommandée](#configuration-initiale-recommandée)
9. [Commandes](#commandes)
10. [Automod en détail](#automod-en-détail)
11. [Anti-raid](#anti-raid)
12. [Logs](#logs)
13. [Bienvenue et au revoir](#bienvenue-et-au-revoir)
14. [Tickets](#tickets)
15. [Niveaux et XP](#niveaux-et-xp)
16. [Giveaways](#giveaways)
17. [Rôles-réactions](#rôles-réactions)
18. [Commandes préfixe](#commandes-préfixe)
19. [Permissions](#permissions)
20. [Données et sauvegarde](#données-et-sauvegarde)
21. [Hébergement](#hébergement)
22. [Dépannage](#dépannage)
23. [Structure du projet](#structure-du-projet)
24. [Sécurité](#sécurité)

---

## Fonctionnalités

### 🛡️ Modération

- Bannissement permanent ou temporaire (`/ban` avec durée)
- Expulsion, softban, timeout et fin de timeout
- Avertissements avec dossier numéroté, historique et suppression
- Purge de messages avec filtres par membre et contenu
- Gestion des salons : mode lent, verrouillage, masquage, nuke
- Modération vocale : mute, unmute, déconnexion, déplacement
- Gestion des rôles et des pseudonymes
- Liste des bannis et débannissement par identifiant
- Dossiers de modération consultables (`/case`, `/history`)
- Mode anti-raid manuel (`/raidmode`)

### 🤖 Automod

- Anti-lien avec liste de domaines autorisés
- Anti-invitation Discord
- Anti-spam et anti-messages répétés
- Anti-majuscules, anti-mentions massives, anti-emojis massifs
- Filtre de mots interdits avec normalisation des accents et du leet speak
- Détection de liens de phishing
- Rôles et salons exemptés
- Sanctions configurables : suppression, avertissement, timeout, expulsion
- Anti-raid automatique avec seuil de joins et âge minimum du compte

### 🎉 Communauté

- Giveaways avec boutons, conditions de rôle/niveau, reroll et persistance
- Sondages à boutons avec vote unique et changement de vote
- Annonces en embed, messages simples et mentions `@everyone`/`@here`
- Messages de bienvenue et d'au revoir personnalisables
- Message privé de bienvenue
- Rôles automatiques à l'arrivée
- Système d'XP, niveaux, classement et récompenses de rôle
- Rôles-réactions par emoji
- Tickets privés avec prise en charge, ajout de membres et transcriptions

### 🧰 Utilitaires

- Aide interactive avec menu de catégories
- Informations serveur, membre, rôle, salon et bot
- Avatar, bannière, uptime, ping
- Lien d'invitation du bot
- `snipe` : dernier message supprimé du salon

### 📝 Logs

- Logs de modération
- Logs des messages (suppression, édition, suppression massive)
- Logs des membres (arrivées, départs, rôles, pseudonymes, timeouts, boosts)
- Logs vocaux
- Logs serveur (salons, rôles, emojis, serveur)
- Logs des tickets

---

## Prérequis

- **Node.js 20 ou supérieur** (testé avec Node.js 24)
- Un compte Discord
- Une application Discord avec un bot
- Les intents privilégiés **Server Members** et **Message Content** activés

Vérifier la version de Node :

```bash
node --version
```

---

## Installation

### 1. Récupérer le projet

Place-toi dans le dossier du bot :

```bash
cd C:\Users\halou\Downloads\bot2bz
```

### 2. Installer les dépendances

```bash
npm install
```

> **Windows / PowerShell** : si `npm` est bloqué par la politique d'exécution, utilise :
>
> ```powershell
> cmd /c "npm.cmd install"
> ```

### 3. Créer le fichier `.env`

Copie `.env.example` vers `.env` :

```powershell
Copy-Item .env.example .env
```

Puis ouvre `.env` et renseigne au minimum `DISCORD_TOKEN` et `CLIENT_ID`.

---

## Configuration `.env`

```env
DISCORD_TOKEN=ton_token_secret
CLIENT_ID=123456789012345678
GUILD_ID=
OWNER_IDS=
DEFAULT_PREFIX=!
```

| Variable | Obligatoire | Description |
|---|---|---|
| `DISCORD_TOKEN` | ✅ | Token du bot (Developer Portal → Bot → Reset Token) |
| `CLIENT_ID` | ✅ | ID de l'application (Developer Portal → General Information) |
| `GUILD_ID` | ❌ | ID d'un serveur de test : déploiement instantané des commandes |
| `OWNER_IDS` | ❌ | IDs des propriétaires du bot, séparés par des virgules. Ils ignorent permissions et cooldowns |
| `DEFAULT_PREFIX` | ❌ | Préfixe texte par défaut (`!` si absent) |

> Le fichier `.env` est ignoré par Git. Ne le partage jamais et ne le commit jamais.

---

## Portail Discord

### 1. Créer l'application et le bot

1. Ouvre [discord.com/developers/applications](https://discord.com/developers/applications).
2. Clique sur **New Application**, donne-lui un nom.
3. Va dans **Bot** → **Add Bot**.
4. Clique sur **Reset Token** et copie le token dans `DISCORD_TOKEN`.
5. Copie l'**Application ID** dans `CLIENT_ID`.

### 2. Activer les intents privilégiés

Dans **Bot** → **Privileged Gateway Intents**, active :

- ✅ **Server Members Intent**
- ✅ **Message Content Intent**

Sans ces intents, le bot ne pourra pas lire les messages, attribuer les autorôles ni modérer correctement.

### 3. Inviter le bot

Dans **OAuth2** → **URL Generator** :

- Scopes : `bot` et `applications.commands`
- Permissions recommandées : **Administrateur** (pour toutes les fonctionnalités)

Ou utilise directement le lien généré par `/invite`.

> Pour un serveur de production, tu peux retirer la permission Administrateur et n'accorder que les permissions listées dans la section [Permissions](#permissions).

---

## Déploiement des commandes

Les commandes slash doivent être enregistrées auprès de Discord **avant** de pouvoir être utilisées.

### Déploiement global

```bash
npm run deploy
```

Les commandes globales peuvent mettre **jusqu'à 1 heure** à apparaître.

### Déploiement instantané sur un serveur de test

Renseigne `GUILD_ID` dans `.env`, puis :

```bash
npm run deploy
```

Les commandes apparaissent immédiatement sur ce serveur.

> Après chaque modification des commandes, relance `npm run deploy`.

---

## Démarrage

```bash
npm start
```

Le bot affiche un récapitulatif :

```text
══════════════════════════════════════════════
  [! 𝘨𝘦𝘴𝘵𝘪𝘰𝘯 ] L2B🎃
  Connecté en tant que MonBot#1234
  X serveur(s) • 58 commande(s)
══════════════════════════════════════════════
```

### Vérification hors ligne

```bash
npm run check
```

Cette commande :

- valide les 58 commandes (noms, descriptions, options, doublons) ;
- charge tous les événements avec un client Discord non connecté ;
- vérifie les gestionnaires (giveaways, base de données) ;
- teste les fonctions critiques (durées, filtres, domaines, XP, anti-raid) ;
- détecte les erreurs d'import et les noms d'événements invalides.

Sortie attendue :

```text
✅ Toutes les commandes sont valides.
🧪 Smoke test : 58 commande(s), 27 gestionnaire(s) d'événements.
✅ Commandes, événements et gestionnaires chargés sans erreur.
✅ Tous les tests de base sont passés.
```

---

## Configuration initiale recommandée

Une fois le bot en ligne, exécute dans cet ordre :

1. `/config view` — vérifier la configuration actuelle
2. `/config logs type:all salon:#logs` — centraliser les logs
3. `/automod status` — vérifier l'automod
4. `/automod antilink activer:true` — ajuster l'anti-lien
5. `/automod antiraid activer:true` — vérifier l'anti-raid
6. `/welcome channel salon:#bienvenue` — activer la bienvenue
7. `/goodbye channel salon:#departs` — activer les départs
8. `/config staff add role:@Modérateur` — donner accès aux commandes de modération
9. `/config autorole add role:@Membre` — autorôle à l'arrivée
10. `/levels config activer:true salon:#niveaux` — activer l'XP
11. `/ticket setup salon_panel:#support categorie:📁Support role_support:@Staff salon_logs:#transcripts`
12. `/giveaway start` — tester un giveaway
13. `/help` — parcourir toutes les commandes

---

## Commandes

> Toutes les commandes slash disposent d'une version préfixe. Les alias sont indiqués quand ils existent.  
> `[]` = option facultative, `<>` = option obligatoire.

### 🛡️ Modération — 26 commandes

| Commande | Description |
|---|---|
| `/ban <membre> [raison] [duree] [messages]` | Bannit un membre. Avec une durée, le bannissement est temporaire et levé automatiquement. `messages` supprime 0 à 7 jours de messages. |
| `/kick <membre> [raison]` | Expulse un membre. |
| `/softban <membre> [raison]` | Bannit puis débannit immédiatement pour supprimer les messages des 7 derniers jours. |
| `/timeout <membre> <duree> [raison]` | Exclut temporairement un membre (28 jours maximum). |
| `/untimeout <membre> [raison]` | Retire un timeout. |
| `/warn <membre> [raison]` | Ajoute un avertissement numéroté. |
| `/warnings [membre]` | Affiche les avertissements d'un membre (ou les tiens). |
| `/delwarn <membre> <identifiant>` | Supprime un avertissement précis. |
| `/clear <nombre> [membre] [contient]` | Supprime de 1 à 100 messages, avec filtres facultatifs. |
| `/case <identifiant>` | Affiche un dossier de modération. |
| `/history <membre>` | Affiche l'historique complet d'un membre. |
| `/banlist [limite]` | Liste les membres bannis. |
| `/unban <utilisateur_id> [raison]` | Débannit un utilisateur par son identifiant. |
| `/nick <membre> [pseudo] [raison]` | Change ou réinitialise le pseudonyme. |
| `/slowmode <secondes> [salon]` | Définit le mode lent (0 à 21 600 secondes). |
| `/lock [salon] [raison]` | Verrouille un salon pour `@everyone`. |
| `/unlock [salon] [raison]` | Déverrouille un salon. |
| `/hide [salon] [raison]` | Cache un salon aux membres. |
| `/unhide [salon] [raison]` | Rend un salon visible. |
| `/nuke [salon] [raison]` | Supprime et recrée un salon (confirmation obligatoire). |
| `/vc-mute <membre> [raison]` | Rend muet un membre en vocal. |
| `/vc-unmute <membre> [raison]` | Rétablit la parole d'un membre en vocal. |
| `/vc-kick <membre> [raison]` | Déconnecte un membre du vocal. |
| `/vc-move <membre> <salon> [raison]` | Déplace un membre dans un autre salon vocal. |
| `/role add <membre> <role> [raison]` | Ajoute un rôle. |
| `/role remove <membre> <role> [raison]` | Retire un rôle. |
| `/raidmode <activer>` | Active ou désactive manuellement l'anti-raid. |

**Alias préfixe utiles :** `bannir`, `expulser`, `softbannir`, `mute`, `exclure`, `unmute`, `avertir`, `warns`, `purge`, `dossier`, `casier`, `bans`, `debannir`, `pseudo`, `verrouiller`, `deverrouiller`, `cacher`, `montrer`, `vcmute`, `vckick`, `vcmove`, `raid`.

---

### 🧰 Utilitaires — 12 commandes

| Commande | Description |
|---|---|
| `/help [commande]` | Aide interactive avec menu par catégorie. |
| `/ping` | Latence aller-retour, WebSocket et uptime. |
| `/botinfo` | Statistiques et informations du bot. |
| `/serverinfo` | Informations du serveur. |
| `/userinfo [membre]` | Informations d'un membre. |
| `/avatar [membre]` | Avatar global et avatar serveur. |
| `/banner [membre]` | Bannière d'un utilisateur. |
| `/roleinfo <role>` | Informations d'un rôle. |
| `/channelinfo [salon]` | Informations d'un salon. |
| `/invite` | Lien d'invitation du bot. |
| `/uptime` | Durée de fonctionnement. |
| `/snipe` | Dernier message supprimé du salon. |

**Alias préfixe :** `aide`, `h`, `latence`, `infobot`, `serveurinfo`, `si`, `qui`, `ui`, `invitation`.

---

### 🎲 Fun — 7 commandes

| Commande | Description |
|---|---|
| `/8ball <question>` | Réponse de la boule magique. |
| `/dice [faces]` | Lance un dé (2 à 1000 faces). |
| `/coinflip` | Pile ou face. |
| `/rps <choix>` | Pierre-feuille-ciseaux. |
| `/choose <options>` | Choisit une option au hasard (séparées par des virgules). |
| `/ship <membre1> [membre2]` | Compatibilité entre deux membres. |
| `/joke` | Blague aléatoire. |

**Alias préfixe :** `boule`, `de`, `pileouface`, `pfc`, `choisir`, `amour`, `blague`.

---

### ⚙️ Configuration — 5 commandes

| Commande | Description |
|---|---|
| `/config view` | Affiche toute la configuration du serveur. |
| `/config prefix <prefixe>` | Change le préfixe texte (1 à 5 caractères). |
| `/config logs <type> [salon]` | Configure un salon de logs. Sans salon, désactive ce type. |
| `/config staff add/remove/list` | Gère les rôles staff (accès modération sans permission Discord). |
| `/config autorole add/remove/list` | Gère les rôles automatiques à l'arrivée. |
| `/automod status` | État complet de l'automod. |
| `/automod global <activer>` | Active ou désactive tout l'automod. |
| `/automod antilink ...` | Configure l'anti-lien. |
| `/automod antiinvite ...` | Configure l'anti-invitation. |
| `/automod antispam ...` | Configure l'anti-spam. |
| `/automod anticaps ...` | Configure l'anti-majuscules. |
| `/automod antimention ...` | Configure l'anti-mentions. |
| `/automod antiemoji ...` | Configure l'anti-emojis. |
| `/automod badwords ...` | Active le filtre et remplace la liste. |
| `/automod badword-add <mots>` | Ajoute des mots interdits. |
| `/automod badword-remove <mots>` | Retire des mots interdits. |
| `/automod antiraid ...` | Configure l'anti-raid. |
| `/automod exempt <cible> <action>` | Exempte un rôle ou un salon. |
| `/automod reset <module>` | Réinitialise un module (ou tout). |
| `/levels config ...` | Configure l'XP et les messages de level-up. |
| `/levels reward <niveau> <role>` | Ajoute une récompense de rôle. |
| `/levels remove <niveau>` | Retire une récompense. |
| `/levels rewards` | Liste les récompenses. |
| `/levels reset [membre]` | Réinitialise l'XP d'un membre ou de tout le serveur. |
| `/levels addxp/removexp/setxp <membre> <montant>` | Gère l'XP manuellement. |
| `/welcome channel/message/embed/toggle/dm/test` | Configure la bienvenue. |
| `/goodbye channel/message/embed/toggle/test` | Configure les départs. |

**Types de logs :** `all`, `mod`, `messages`, `members`, `voice`, `server`, `tickets`.

> Le type `all` sert de fallback : si un type précis n'a pas de salon, les logs sont envoyés dans `all`.

---

### 📢 Annonces — 3 commandes

| Commande | Description |
|---|---|
| `/announce <salon> <titre> <message> [couleur] [mention] [image]` | Envoie une annonce en embed. `mention` : aucune, `@everyone` ou `@here`. |
| `/say <salon> <message>` | Envoie un message simple en tant que bot. |
| `/poll <salon> <question> <option1> <option2> [option3] [option4] [option5]` | Crée un sondage à boutons. Un membre ne peut voter que pour un choix ; recliquer retire le vote. |

**Alias préfixe :** `annonce`, `dire`, `sondage`.

> L'utilisation de `@everyone` ou `@here` nécessite la permission **Mentionner @everyone** pour l'auteur de la commande.

---

### 🎉 Giveaways — 1 commande

| Commande | Description |
|---|---|
| `/giveaway start <prix> <duree> [gagnants] [salon] [description] [role_requis] [niveau_requis]` | Lance un giveaway. Durée de 10 secondes à 30 jours, 1 à 20 gagnants. |
| `/giveaway end [identifiant]` | Termine immédiatement un giveaway (par défaut : le dernier actif). |
| `/giveaway reroll [identifiant]` | Retire un nouveau gagnant parmi les autres participants (par défaut : le dernier giveaway terminé). |
| `/giveaway list` | Liste les giveaways actifs et terminés. |
| `/giveaway info [identifiant]` | Détails d'un giveaway. |
| `/giveaway delete [identifiant]` | Supprime un giveaway et son message (confirmation). |

Les boutons **Participer** et **Quitter** sont persistants après un redémarrage. Les conditions de rôle et de niveau sont vérifiées au moment de la participation.

---

### 📈 Niveaux — 2 commandes

| Commande | Description |
|---|---|
| `/rank [membre]` | Niveau, XP, classement et progression. |
| `/leaderboard` | Top 10 du serveur. |

La configuration se fait avec `/levels ...` (catégorie Configuration).

---

### 🎭 Rôles — 1 commande

| Commande | Description |
|---|---|
| `/reactionrole add <salon> <message_id> <emoji> <role>` | Ajoute un rôle-réaction. |
| `/reactionrole remove <message_id> <emoji>` | Retire un rôle-réaction. |
| `/reactionrole list` | Liste les rôles-réactions. |
| `/reactionrole clear <message_id>` | Supprime tous les rôles-réactions d'un message. |

**Alias préfixe :** `rr`, `reactionrole`.

---

### 🎫 Tickets — 1 commande

| Commande | Description |
|---|---|
| `/ticket setup <salon_panel> [categorie] [role_support] [salon_logs]` | Configure et active les tickets, puis envoie le panneau. |
| `/ticket panel [salon]` | Renvoie le panneau d'ouverture. |
| `/ticket welcome <texte>` | Message d'accueil dans les tickets. |
| `/ticket panel-message <texte>` | Description du panneau. |
| `/ticket toggle <activer>` | Active ou désactive le système. |
| `/ticket stats` | Statistiques des tickets. |
| `/ticket close [raison]` | Ferme le ticket courant et envoie un transcript. |
| `/ticket add <membre>` | Ajoute un membre au ticket. |
| `/ticket remove <membre>` | Retire un membre du ticket. |

**Alias préfixe :** `tickets`, `support`.

---

## Automod en détail

### Sanctions disponibles

| Valeur | Effet |
|---|---|
| `delete` | Supprime le message (par défaut) |
| `warn` | Supprime le message et crée un avertissement |
| `timeout` | Supprime le message et exclut temporairement le membre |
| `kick` | Supprime le message et expulse le membre |

La durée du timeout est configurable de **10 secondes à 28 jours**.

### Modules

| Module | Option | Valeur par défaut |
|---|---|---|
| Anti-lien | `activer`, `action`, `duree`, `domaines`, `phishing` | Activé, suppression, anti-phishing activé |
| Anti-invitation | `activer`, `action`, `duree` | Activé, suppression |
| Anti-spam | `activer`, `messages`, `secondes`, `action`, `duree` | 6 messages / 7 s, timeout 10 min |
| Anti-majuscules | `activer`, `pourcentage`, `longueur_min`, `action`, `duree` | 75 % sur 14 lettres, suppression |
| Anti-mentions | `activer`, `maximum`, `action`, `duree` | 6 mentions max, suppression |
| Anti-emojis | `activer`, `maximum`, `action`, `duree` | Désactivé, 15 emojis max |
| Mots interdits | `activer`, `mots`, `badword-add`, `badword-remove` | Activé |
| Anti-raid | `activer`, `seuil`, `secondes`, `age_compte`, `verrouillage` | Activé, 8 joins / 20 s, comptes < 7 jours |

### Domaines autorisés par défaut

YouTube, Twitch, Twitter/X, Instagram, TikTok, Spotify, GitHub, GitLab, Tenor, Giphy, Imgur, Reddit, Google, Wikipédia, Discord/CDN, Steam Community, Roblox, Epic Games.

La liste est **remplacée intégralement** par `/automod antilink domaines:...`. Sépare les domaines par des virgules.

### Exemptions

```text
/automod exempt cible:@Modérateur action:Ajouter
/automod exempt cible:#spam action:Ajouter
/automod exempt cible:@Modérateur action:Retirer
```

Sont également exemptés automatiquement :

- le propriétaire du serveur ;
- les membres avec **Administrateur**, **Gérer le serveur**, **Gérer les messages** ou **Gérer les exclusions temporaires** ;
- les rôles staff configurés avec `/config staff add`.

### Ordre des vérifications

1. Anti-invitation
2. Anti-lien / anti-phishing
3. Mots interdits
4. Anti-spam
5. Anti-mentions
6. Anti-majuscules
7. Anti-emojis

Le premier module déclenché applique sa sanction et arrête l'analyse.

### Réinitialisation

```text
/automod reset module:Tout
/automod reset module:Anti-lien
/automod reset module:Anti-spam
```

Modules acceptés : `all`, `antilink`, `antiinvite`, `antispam`, `anticaps`, `antimention`, `antiemoji`, `badwords`, `antiraid`.

---

## Anti-raid

L'anti-raid surveille les arrivées de membres.

- **Seuil par défaut :** 8 arrivées en 20 secondes.
- Au déclenchement, le mode anti-raid s'active pendant **10 minutes**.
- Pendant cette période, les comptes créés il y a **moins de `age_compte` jours** sont expulsés automatiquement.
- Un dossier de modération `raid` et un log sont créés pour chaque expulsion.
- Si `verrouillage` est activé, le niveau de vérification du serveur passe à **Très élevé**.

Configuration :

```text
/automod antiraid activer:true seuil:8 secondes:20 age_compte:7 verrouillage:false
```

Mode manuel :

```text
/raidmode activer:true    → 1 heure de protection
/raidmode activer:false   → désactivation immédiate
```

> Le verrouillage de vérification n'est pas rétabli automatiquement après le raid. Repasse manuellement le niveau de vérification à la valeur souhaitée.

---

## Logs

Configure un salon par type :

```text
/config logs type:Tous les logs salon:#logs
/config logs type:Modération salon:#logs-mod
/config logs type:Messages salon:#logs-messages
/config logs type:Membres salon:#logs-membres
/config logs type:Vocal salon:#logs-vocal
/config logs type:Serveur salon:#logs-serveur
/config logs type:Tickets salon:#transcripts
```

Pour désactiver un type, omets le salon :

```text
/config logs type:Messages
```

Le bot doit avoir **Voir le salon**, **Envoyer des messages** et **Intégrer des liens** dans le salon de logs.

### Événements journalisés

- **Modération :** bans, débans, kicks, softbans, timeouts, avertissements, automod, anti-raid, tickets
- **Messages :** suppression, édition, suppression massive
- **Membres :** arrivée, départ, pseudonyme, rôles, timeout, boost
- **Vocal :** connexion, déconnexion, déplacement, mute/deaf, stream, caméra
- **Serveur :** salon créé/modifié/supprimé, rôle créé/modifié/supprimé, emoji ajouté/supprimé, serveur modifié
- **Tickets :** ouverture, fermeture, transcription

---

## Bienvenue et au revoir

### Configuration

```text
/welcome channel salon:#bienvenue
/welcome message texte:Bienvenue {user} sur **{server}** ! Nous sommes {count} membres.
/welcome embed activer:true
/welcome toggle activer:true
/welcome dm activer:true
/welcome test

/goodbye channel salon:#departs
/goodbye message texte:**{username}** a quitté le serveur. À bientôt !
/goodbye embed activer:true
/goodbye toggle activer:true
/goodbye test
```

### Variables disponibles

| Variable | Résultat |
|---|---|
| `{user}` | Mention du membre |
| `{mention}` | Mention du membre |
| `{username}` | Nom d'utilisateur |
| `{tag}` | Tag complet (ou nom d'utilisateur) |
| `{nickname}` | Surnom sur le serveur |
| `{server}` | Nom du serveur |
| `{count}` | Nombre de membres |
| `{created}` | Date de création du compte (format Discord) |
| `{id}` | Identifiant du membre |

Le message privé de bienvenue est uniquement disponible pour `welcome`. Il échoue silencieusement si le membre a fermé ses MP.

---

## Tickets

### Mise en place

```text
/ticket setup salon_panel:#support categorie:📁 Support role_support:@Staff salon_logs:#transcripts
```

Cela :

1. active les tickets ;
2. enregistre les salons et le rôle support ;
3. envoie le panneau avec le bouton **Ouvrir un ticket**.

### Fonctionnement

- Un membre clique sur **Ouvrir un ticket**.
- Un salon privé `ticket-0001-pseudo` est créé.
- Le membre, le bot et le rôle support peuvent voir le salon.
- Le staff peut cliquer sur **Prendre en charge**.
- Le propriétaire ou le staff peut cliquer sur **Fermer le ticket**.
- Le salon est supprimé après **5 secondes**.
- Une transcription `.txt` est envoyée dans le salon de logs tickets.

Un membre ne peut avoir qu'un seul ticket ouvert à la fois. Si son ancien ticket a été supprimé manuellement, le bot nettoie automatiquement l'ancienne entrée.

### Commandes utiles

```text
/ticket stats
/ticket add membre:@Utilisateur
/ticket remove membre:@Utilisateur
/ticket close raison:Problème résolu
```

---

## Niveaux et XP

### Configuration

```text
/levels config activer:true salon:#niveaux xp_min:15 xp_max:25 cooldown:60
```

| Paramètre | Défaut | Description |
|---|---|---|
| `activer` | `true` | Active le gain d'XP |
| `salon` | salon courant | Salon des messages de level-up |
| `xp_min` | 15 | XP minimum par message |
| `xp_max` | 25 | XP maximum par message |
| `cooldown` | 60 | Secondes entre deux gains d'XP |

### Formule

L'XP total nécessaire pour atteindre le niveau `L` est la somme, pour `i` de 1 à `L`, de :

```text
5 × i² + 50 × i + 100
```

Exemples :

| Niveau | XP total requis |
|---|---|
| 1 | 155 |
| 2 | 375 |
| 3 | 670 |
| 5 | 1 525 |
| 10 | 5 675 |

### Récompenses

```text
/levels reward niveau:5 role:@Actif
/levels reward niveau:10 role:@Habitué
/levels rewards
/levels remove niveau:5
```

Le rôle est attribué automatiquement lors du passage au niveau. Si le rôle est au-dessus du rôle le plus haut du bot, un avertissement est ajouté au message de level-up.

### Gestion manuelle

```text
/levels addxp membre:@Utilisateur montant:500
/levels removexp membre:@Utilisateur montant:100
/levels setxp membre:@Utilisateur montant:0
/levels reset membre:@Utilisateur
/levels reset
```

### Consultation

```text
/rank
/rank membre:@Utilisateur
/leaderboard
```

---

## Giveaways

### Lancer

```text
/giveaway start prix:Nitro 1 mois duree:24h gagnants:1 salon:#giveaways
```

Options :

- `prix` : lot à gagner (100 caractères max)
- `duree` : `10m`, `1h`, `2j`, `1h30`, `2j12h`… (10 s à 30 jours)
- `gagnants` : 1 à 20
- `salon` : salon d'envoi (par défaut le salon courant)
- `description` : règles ou détails
- `role_requis` : rôle obligatoire pour participer
- `niveau_requis` : niveau minimum

### Gérer

```text
/giveaway list
/giveaway info identifiant:123456789012345678
/giveaway end identifiant:123456789012345678
/giveaway reroll identifiant:123456789012345678
/giveaway delete identifiant:123456789012345678
```

Sans identifiant :

- `end`, `info`, `delete` utilisent le **dernier giveaway actif** ;
- `reroll` utilise le **dernier giveaway terminé**.

L'identifiant peut être l'ID du message ou l'ID interne du giveaway.

### Persistance

Les giveaways actifs sont restaurés au démarrage. Si la date de fin est dépassée pendant que le bot était hors ligne, le giveaway est terminé automatiquement au redémarrage.

---

## Rôles-réactions

```text
/reactionrole add salon:#roles message_id:123456789012345678 emoji:🎉 role:@Giveaway
/reactionrole list
/reactionrole remove message_id:123456789012345678 emoji:🎉
/reactionrole clear message_id:123456789012345678
```

- Emojis unicode et emojis personnalisés acceptés.
- Le bot ajoute lui-même la réaction au message.
- Ajouter la réaction donne le rôle ; la retirer retire le rôle.
- Le rôle doit être sous le rôle le plus haut du bot.
- Les événements de réaction partiels sont gérés (réactions après redémarrage).

---

## Commandes préfixe

Le préfixe par défaut est `!`. Il se change avec :

```text
/config prefix prefixe:?
```

Exemples :

```text
!help
!ban @membre "spam répété" 1j 7
!clear 50 @membre
!giveaway start "Nitro 1 mois" 24h 1 #giveaways
!poll #sondages "Quel jeu ?" "Minecraft" "Valorant"
```

### Règles de lecture

- Les guillemets `"..."`, `'...'` et les backticks permettent de garder les espaces.
- Les options sont lues dans l'ordre de la commande slash.
- La dernière option texte absorbe automatiquement les mots restants.
- Les mentions, IDs, salons et rôles sont résolus automatiquement.
- Les booléens acceptent : `oui/non`, `true/false`, `on/off`, `1/0`, `activer/désactiver`.
- Les durées acceptent les unités françaises et courtes : `s`, `m`, `h`, `j`, `sem`, `mois`.

En cas d'erreur, le bot affiche la syntaxe attendue.

---

## Permissions

### Permissions Discord du bot

Pour toutes les fonctionnalités, le plus simple est d'accorder **Administrateur**.

Permissions minimales par domaine :

| Fonction | Permissions |
|---|---|
| Commandes de base | Voir les salons, Envoyer des messages, Intégrer des liens, Lire l'historique |
| Modération | Gérer les messages, Expulser des membres, Bannir des membres, Gérer les exclusions temporaires |
| Salons | Gérer les salons |
| Rôles | Gérer les rôles, Gérer les pseudonymes |
| Vocal | Mute Members, Move Members, Se connecter |
| Logs et annonces | Voir les salons, Envoyer des messages, Intégrer des liens, Joindre des fichiers |
| Tickets | Gérer les salons, Gérer les rôles, Joindre des fichiers |
| Rôles-réactions | Gérer les rôles, Ajouter des réactions, Lire l'historique |
| Giveaways | Envoyer des messages, Intégrer des liens |
| Niveaux | Gérer les rôles (pour les récompenses) |

Le bot doit être **au-dessus** des rôles qu'il doit gérer dans la hiérarchie du serveur.

### Permissions des utilisateurs

Chaque commande vérifie les permissions Discord nécessaires. Les exceptions :

- les **propriétaires du bot** (`OWNER_IDS`) ignorent toutes les permissions et les cooldowns ;
- les **rôles staff** (`/config staff add`) peuvent utiliser les commandes de modération sans avoir les permissions Discord correspondantes ;
- le **propriétaire du serveur** est toujours autorisé pour les commandes de modération.

Les vérifications de hiérarchie restent appliquées : personne ne peut sanctionner un membre dont le rôle est égal ou supérieur au sien, ni le propriétaire du serveur.

---

## Données et sauvegarde

Toutes les données sont stockées dans :

```text
data/database.json
```

Contenu :

- configuration par serveur ;
- avertissements et dossiers de modération ;
- bannissements temporaires ;
- giveaways et sondages ;
- tickets ouverts et compteur ;
- rôles-réactions ;
- niveaux et XP ;
- autorôles et rôles staff.

### Sauvegarde

Copie simplement le fichier :

```powershell
Copy-Item data\database.json data\database.backup.json
```

### Restauration

Arrête le bot, remplace `data/database.json` par la sauvegarde, puis redémarre.

### En cas de corruption

Le bot détecte un JSON invalide, crée une copie `database.json.corrupt-<timestamp>.bak` et repart sur une base vide. Tu peux restaurer une sauvegarde manuellement.

> Le dossier `data/` est ignoré par Git. Pense à sauvegarder `database.json` avant toute mise à jour importante.

---

## Hébergement

### Windows

```powershell
cmd /c "npm.cmd start"
```

Pour maintenir le bot en vie, utilise un planificateur de tâches ou un gestionnaire de processus.

### Linux / VPS

```bash
npm install --omit=dev
npm start
```

### PM2

```bash
npm install -g pm2
pm2 start src/index.js --name l2b-gestion
pm2 save
pm2 startup
```

### Pterodactyl / panel

- Type : Node.js
- Fichier principal : `src/index.js`
- Commande de démarrage : `npm start`
- Node.js 20+
- Ajoute les variables d'environnement `DISCORD_TOKEN`, `CLIENT_ID`, etc.

### Mise à jour

```bash
npm install
npm run check
npm run deploy
npm start
```

> Le déploiement des commandes est nécessaire après toute modification des noms, descriptions ou options.

---

## Dépannage

### `DISCORD_TOKEN est introuvable`

- Vérifie que le fichier s'appelle bien `.env` (et non `.env.txt`).
- Vérifie qu'il est à la racine du projet.
- Vérifie que la ligne `DISCORD_TOKEN=...` ne contient pas d'espaces autour du `=`.

### `Used disallowed intents`

Active **Server Members Intent** et **Message Content Intent** dans le portail Discord, puis redémarre.

### Les commandes slash n'apparaissent pas

1. Lance `npm run deploy`.
2. Vérifie `CLIENT_ID`.
3. Si tu utilises `GUILD_ID`, vérifie que le bot est bien sur ce serveur.
4. Réinvite le bot avec le scope `applications.commands`.
5. Attends jusqu'à 1 heure pour les commandes globales.
6. Redémarre ton client Discord (Ctrl+R).

### Le bot ne peut pas modérer

- Vérifie que le bot a les permissions nécessaires.
- Vérifie que son rôle est au-dessus de la cible.
- Vérifie qu'il n'essaie pas de sanctionner le propriétaire du serveur.
- Vérifie que l'utilisateur qui exécute la commande a les permissions ou un rôle staff.

### Les logs ne s'envoient pas

- Vérifie `/config view`.
- Vérifie que le salon est textuel.
- Vérifie les permissions **Voir le salon**, **Envoyer des messages** et **Intégrer des liens**.
- Vérifie que le type de log est configuré ou que `all` l'est.

### `npm` est bloqué sous PowerShell

```powershell
cmd /c "npm.cmd install"
cmd /c "npm.cmd run check"
cmd /c "npm.cmd start"
```

Ou autorise l'exécution pour la session :

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
```

### Le bot redémarre ou s'arrête

- Vérifie les logs de la console.
- Vérifie que le token est valide.
- Vérifie que Node.js est en version 20+.
- Vérifie que `data/` est accessible en écriture.

### Les giveaways ne se terminent pas

- Le bot doit être en ligne à l'heure de fin, ou redémarré après cette heure.
- Vérifie que le message du giveaway existe encore.
- Vérifie que le bot peut écrire dans le salon.

---

## Structure du projet

```text
bot2bz/
├── .env.example
├── .gitignore
├── package.json
├── README.md
├── data/
│   └── database.json          # créé automatiquement
├── scripts/
│   ├── check.js               # validation des commandes
│   ├── smoke.js               # test de chargement des événements
│   └── test-core.js           # tests des fonctions critiques
└── src/
    ├── index.js               # point d'entrée, client Discord
    ├── deploy-commands.js     # déploiement des slash commands
    ├── commands/              # 58 commandes
    │   ├── announcements.js
    │   ├── automod.js
    │   ├── channels.js
    │   ├── config.js
    │   ├── fun.js
    │   ├── giveaway.js
    │   ├── greetings.js
    │   ├── levels.js
    │   ├── moderation.js
    │   ├── reactionroles.js
    │   ├── tickets.js
    │   └── utility.js
    ├── core/                  # logique métier
    │   ├── automod.js
    │   ├── cases.js
    │   ├── config.js
    │   ├── context.js
    │   ├── db.js
    │   ├── giveaways.js
    │   ├── greetings.js
    │   ├── levels.js
    │   ├── logs.js
    │   ├── polls.js
    │   ├── reactionHandler.js
    │   ├── reactionroles.js
    │   ├── tempbans.js
    │   ├── tickets.js
    │   └── utils.js
    ├── events/                # 27 gestionnaires d'événements
    └── handlers/
        ├── commands.js
        └── events.js
```

---

## Sécurité

- Ne partage **jamais** ton token Discord.
- Ne commit **jamais** `.env`.
- Si ton token a fuité, clique sur **Reset Token** dans le portail Discord.
- Limite `OWNER_IDS` aux personnes de confiance.
- Accorde **Administrateur** uniquement si nécessaire ; sinon, utilise les permissions minimales.
- Sauvegarde régulièrement `data/database.json`.
- Vérifie les permissions des salons de logs et transcripts : ils peuvent contenir des données privées.

---

## Licence

MIT — utilise, modifie et héberge ce bot librement.

---

**Bon jeu et bonne modération avec [! 𝘨𝘦𝘴𝘵𝘪𝘰𝘯 ] L2B🎃 !**
